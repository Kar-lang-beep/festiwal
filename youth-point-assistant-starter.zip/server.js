import express from "express";
import dotenv from "dotenv";
import path from "path";
import fs from "fs";
import fetch from "node-fetch";

dotenv.config();

const app = express();
app.use(express.json());
app.use(express.static(path.join(process.cwd(), "public")));

// ---- KONFIG ----
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
const MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";

// Wczytywanie bazy wiedzy i system promptu
const knowledgePath = path.join(process.cwd(), "content", "knowledge.json");
const systemPath = path.join(process.cwd(), "prompts", "system.txt");
const knowledge = JSON.parse(fs.readFileSync(knowledgePath, "utf-8"));
const systemPrompt = fs.readFileSync(systemPath, "utf-8");

// Słowa/frazy kryzysowe (minimalny zestaw; rozwiń go z psychologiem)
const CRISIS_TRIGGERS = [
  "samobój", "nie chcę żyć", "skrzywdzić się", "zrobić sobie krzywdę",
  "autoagresja", "okaleczyć", "zabiję się", "mam dość życia"
];

// Komunikat bezpieczeństwa
const SAFETY_RESPONSE = `Widzę, że to może być bardzo trudne. Nie jesteś w tym sam/a.
• Zadzwoń: 116 111 (Telefon Zaufania dla Dzieci i Młodzieży), 112 w nagłym zagrożeniu.
• Skontaktuj się z dorosłą, zaufaną osobą lub psychologiem.
• Jeśli jesteś na wydarzeniu Youth Point: podejdź do punktu informacji — poproś o kontakt z dyżurującym specjalistą.
Pamiętaj: jestem narzędziem psychoedukacyjnym, nie zastępuję profesjonalnej pomocy.`;

// Prosta funkcja wykrywania kryzysu
function isCrisis(text) {
  const t = (text || "").toLowerCase();
  return CRISIS_TRIGGERS.some(k => t.includes(k));
}

// Budowa wiadomości: system + kontekst bazy wiedzy + user
function buildMessages(userText) {
  const knowledgeBlock = `KONTEKST BAZY WIEDZY:\n${JSON.stringify(knowledge, null, 2)}`;
  return [
    { role: "system", content: systemPrompt },
    { role: "system", content: knowledgeBlock },
    { role: "user", content: userText }
  ];
}

// Endpoint zdrowia
app.get("/health", (_, res) => res.json({ ok: true }));

// Główny endpoint czatu
app.post("/chat", async (req, res) => {
  const { message } = req.body || {};
  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "Brak 'message' w body." });
  }

  // Eskalacja kryzysowa — natychmiastowy bezpieczny komunikat + zasoby
  if (isCrisis(message)) {
    return res.json({ reply: SAFETY_RESPONSE, crisis: true });
  }

  if (!OPENAI_API_KEY) {
    return res.status(500).json({ error: "Brak OPENAI_API_KEY w .env" });
  }

  try {
    const resp = await fetch(OPENAI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: MODEL,
        temperature: 0.4,
        messages: buildMessages(message)
      })
    });

    if (!resp.ok) {
      const text = await resp.text();
      return res.status(500).json({ error: "Błąd API", detail: text });
    }

    const data = await resp.json();
    const reply = data?.choices?.[0]?.message?.content?.trim() || "Przepraszam, spróbuj proszę jeszcze raz.";
    res.json({ reply, crisis: false });
  } catch (e) {
    res.status(500).json({ error: "Błąd serwera", detail: String(e) });
  }
});

// Start
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Youth Point Assistant działa na http://localhost:${PORT}`));
