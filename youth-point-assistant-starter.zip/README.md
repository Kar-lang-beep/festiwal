# Youth Point Assistant — starter kit (Node.js)

Prosty chatbot dla festiwalu Youth Point (PL), z naciskiem na wsparcie dobrostanu i bezpieczeństwo treści.

## Funkcje
- Webowy widget czatu (HTML/JS).
- Backend Express `/chat` z prostą warstwą bezpieczeństwa (wykrywanie kryzysu).
- „Baza wiedzy” (content/knowledge.json) + system prompt (prompts/system.txt).
- Gotowe komunikaty bezpieczeństwa (116 111, 112, lokalne wsparcie).
- Łatwe osadzenie na stronie (iframe lub bezpośrednio jako podstrona).

## Wymagania
- Node.js 18+
- Klucz API (np. OpenAI) — wklej do `.env`

## Szybki start
```bash
npm install
cp .env.example .env   # wpisz swój OPENAI_API_KEY
npm run dev            # http://localhost:3000
```
Osadzenie: umieść to jako podstronę (np. `/asystent`) lub wstawek iframe na główną stronę festiwalu.

## Konfiguracja
- `prompts/system.txt` — ton, rola, reguły bezpieczeństwa.
- `content/knowledge.json` — FAQ festiwalu, kontakty, warsztaty, materiały po-festiwalowe.
- `server.js` — słowa kluczowe do wykrywania kryzysu, komunikaty bezpieczeństwa, wybór modelu.

## Uwaga dot. bezpieczeństwa
Bot **nie prowadzi diagnozy ani terapii**. W treściach zawarte są procedury eskalacji (numery kryzysowe).
Zadbaj o przegląd treści przez psychologa oraz regularne aktualizacje.

## Licencja
MIT — dostosuj do swoich potrzeb.
