import express from "express";
import dotenv from "dotenv";
import path from "path";
import fs from "fs";
import fetch from "node-fetch";

dotenv.config();
const app = express();
app.use(express.json());
app.use(express.static(path.join(process.cwd(), "public")));

const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || "http://localhost:11434";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "mistral";

// Wczytanie bazy wiedzy i system promptu
const knowledgePath = path.join(process.cwd(), "content", "knowledge.json");
const systemPath = path.join(process.cwd(), "prompts", "system.txt");
const knowledge = JSON.parse(fs.readFileSync(knowledgePath, "utf-8"));
const systemPrompt = fs.readFileSync(systemPath, "utf-8");

// Słowa/frazy kryzysowe – skonsultuj i rozszerz z psychologiem
const CRISIS_TRIGGERS = [
  "samobój", "nie chcę żyć", "skrzywdzić się", "zrobić sobie krzywdę",
  "autoagresja", "okaleczyć", "zabiję się", "mam dość życia"
];

const SAFETY_RESPONSE = `Widzę, że to może być bardzo trudne. Nie jesteś w tym sam/a.
• Zadzwoń: 116 111 (Telefon Zaufania dla Dzieci i Młodzieży), 112 w nagłym zagrożeniu.
• Porozmawiaj z zaufaną osobą dorosłą lub psychologiem.
• Jeśli jesteś na Youth Point: podejdź do punktu informacji i poproś o kontakt z dyżurującym specjalistą.
Pamiętaj: jestem narzędziem psychoedukacyjnym, nie zastępuję profesjonalnej pomocy.`;

function isCrisis(text) {
  const t = (text || "").toLowerCase();
  return CRISIS_TRIGGERS.some(k => t.includes(k));
}

function buildPrompt(userText) {
  const knowledgeBlock = `KONTEKST BAZY WIEDZY:\n${JSON.stringify(knowledge, null, 2)}`;
  return `${systemPrompt}\n\n${knowledgeBlock}\n\nUŻYTKOWNIK:\n${userText}\nODPOWIEDŹ:`;
}

// Zdrowie
app.get("/health", (_, res) => res.json({ ok: true }));

// Chat – używa Ollama /api/generate (simple prompt)
app.post("/chat", async (req, res) => {
  const { message } = req.body || {};
  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "Brak 'message' w body." });
  }

  // Eskalacja kryzysowa
  if (isCrisis(message)) {
    return res.json({ reply: SAFETY_RESPONSE, crisis: true });
  }

  // Połączenie z Ollama
  try {
    const resp = await fetch(`${OLLAMA_BASE_URL}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        prompt: buildPrompt(message),
        stream: false,
        options: { temperature: 0.4 }
      })
    });

    if (!resp.ok) {
      const text = await resp.text();
      return res.status(500).json({ error: "Błąd Ollama", detail: text });
    }

    const data = await resp.json();
    const reply = (data?.response || "").trim() || "Nie doszła odpowiedź z modelu. Spróbuj proszę ponownie.";
    res.json({ reply, crisis: false });
  } catch (e) {
    res.status(500).json({ error: "Błąd serwera", detail: String(e) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Youth Point Assistant (Ollama) → http://localhost:${PORT}`));
