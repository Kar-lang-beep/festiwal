# Youth Point Assistant — local, open‑source (Ollama)
Offline-ish chatbot wspierający dobrostan, bez kluczy i opłat. Działa z modelem open‑source przez **Ollama**.

## Co dostajesz
- Webowy czat (HTML/JS) + backend Express (`server.ollama.js`).
- Połączenie z lokalnym modelem (np. `mistral`, `llama3.1`, `qwen2`).
- Warstwa bezpieczeństwa (wykrywanie kryzysu → numery pomocy).
- System prompt + baza wiedzy do podmiany.

## Wymagania
- Node.js 18+
- Ollama (macOS/Windows/Linux): https://ollama.com/
- Pobrany model, np.: `ollama pull mistral`

## Szybki start
```bash
# 1) Zainstaluj Ollama i uruchom w tle
# 2) Pobierz model (np. mistral)
ollama pull mistral

# 3) Zainstaluj paczki i odpal serwer
npm install
npm run dev   # http://localhost:3000
```

## Zmiana modelu
Domyślnie: `MISTRAL`. Możesz ustawić `OLLAMA_MODEL` na `llama3.1`, `qwen2`, itp.
W pliku `.env.example` masz:
```
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=mistral
PORT=3000
```

## Pliki do edycji
- `prompts/system.txt` – ton, rola, zasady.
- `content/knowledge.json` – FAQ, program, kontakty, ćwiczenia.

## Bezpieczeństwo
Asystent nie prowadzi terapii ani diagnozy. Słowa-klucze wywołują bezpieczny komunikat (116 111, 112, kontakt lokalny). Skonsultuj listę triggerów z psychologiem i aktualizuj regularnie.

## Licencja
MIT
